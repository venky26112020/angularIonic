﻿using Consultations.API.Controllers;
using Consultations.API.Models;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Service.CommandHandlers;
using Consultations.Service.QueryHandlers;
using dCaf.Core;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultations.Tests.Controllers
{
    public class PatientIntakeResponsesControllerTests
    {
        [Fact]
        public async Task Patient_Intake_Response_should_return_Success()
        {
            // Arrange
            int AppointmentId = 1;
            int PatientId = 1;

            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var controller = new PatientIntakeResponsesController(mockMediator.Object);

            var mockHandler = new Mock<IExecuteDataRequestAsync<int, int, List<PatientIntakeResponses>>>();
            mockHandler.Setup(x => x.ExecuteAsync(AppointmentId, PatientId)).ReturnsAsync(It.IsAny<List<PatientIntakeResponses>>);
            var handler = new GetPatientIntakeResponseQueryHandlers(mockHandler.Object);
            await handler.Handle(new GetPatientIntakeResponseQuery(AppointmentId, PatientId), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.GetPatientIntakeResponses(AppointmentId, PatientId);

            //Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task Patient_Intake_Response_should_return_Failure()
        {
            // Arrange
            int AppointmentId = 0;
            int PatientId = 0;

            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var controller = new PatientIntakeResponsesController(mockMediator.Object);

            var mockHandler = new Mock<IExecuteDataRequestAsync<int, int, List<PatientIntakeResponses>>>();
            mockHandler.Setup(x => x.ExecuteAsync(AppointmentId, PatientId)).ReturnsAsync(It.IsAny<List<PatientIntakeResponses>>);
            var handler = new GetPatientIntakeResponseQueryHandlers(mockHandler.Object);
            await handler.Handle(new GetPatientIntakeResponseQuery(AppointmentId, PatientId), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.GetPatientIntakeResponses(AppointmentId, PatientId);

            //Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SaveIntakeResponse_Should_Return_Success()
        {
            // Arrange                       
            List<PatientIntakeResponses> intakelist = new()
            {
               new PatientIntakeResponses
               {
                  AppointmentId =1,
                  PatientId=1,
                  Question="",
                  QuestionResponse="",
                  FollowupQuestion="",
                  FollowupResponse="",
                  IsWeightageTitle=true
                }
            };
            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var controller = new PatientIntakeResponsesController(mockMediator.Object);

            var mockHandler = new Mock<IExecuteDataRequestAsync<List<PatientIntakeResponses>, ActionResult<dCaf.Core.Response<string>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<List<PatientIntakeResponses>>())).ReturnsAsync(It.IsAny<ActionResult<dCaf.Core.Response<string>>>);
            var handler = new SavePatientsIntakeResponsesCommandHandler(mockHandler.Object);
            await handler.Handle(new SavePatientsIntakeResponsesCommand(intakelist), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.SavePatientsIntakeResponses(intakelist);

            //Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SaveIntakeResponse_Should_Return_Unsuccess()
        {
            // Arrange                       
            List<PatientIntakeResponses> intakelist = new()
            {
               new PatientIntakeResponses
               {
                  AppointmentId =0,
                  PatientId=0,
                  Question="",
                  QuestionResponse="",
                  FollowupQuestion="",
                  FollowupResponse="",
                  IsWeightageTitle=false
                }
            };
            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var controller = new PatientIntakeResponsesController(mockMediator.Object);

            var mockHandler = new Mock<IExecuteDataRequestAsync<List<PatientIntakeResponses>, ActionResult<dCaf.Core.Response<string>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<List<PatientIntakeResponses>>())).ReturnsAsync(It.IsAny<ActionResult<dCaf.Core.Response<string>>>);
            var handler = new SavePatientsIntakeResponsesCommandHandler(mockHandler.Object);
            await handler.Handle(new SavePatientsIntakeResponsesCommand(intakelist), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.SavePatientsIntakeResponses(intakelist);

            //Assert
            Assert.NotNull(result);
        }
    }
}
