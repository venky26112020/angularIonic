﻿using Consultations.API.Controllers;
using Consultations.Core.Domain;
using Consultations.Core;
using Consultations.Data;
using Consultations.Service.CommandHandlers;
using dCaf.Core;
using MediatR;
using Moq;
using Consultations.Tests.Commands;
using Consultations.Data.Commands;
using Consultations.Data.TwilioService;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using Consultations.Service.QueryHandlers;
using Consultations.API.Models;

namespace Consultations.Tests.Controllers
{
    public class VendorConsultRoomControllerTests
    {
        [Theory]
        [InlineData(4, "provider", "1")]
        [InlineData(3, "provider", "3")]
        [InlineData(1, "provider", "1")]
        [InlineData(1, "patient", "1")]
        [InlineData(3, "patient", "3")]
        [InlineData(1, "admin", "1")]
        [InlineData(2, "provider", "1")]
        public async Task SaveVendorConsultRoom(int consultationId, string entityType, string providerconsultId)
        {
            // Arrange

            AddParticipatData addParticipatData = new AddParticipatData()
            {
            appointmentId = consultationId,
            entityType = entityType,
            providerconsultId = providerconsultId
            };
            List<Appointments> appontmentlist = new()
            {
                new Appointments {
                    Id = 1,
                    AppointmentType = "Scheduled",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 1,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now.AddMinutes(-10),
                    EndDateTime = DateTime.Now.AddMinutes(10),
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                },
                new Appointments {
                    Id = 2,
                    AppointmentType = "OnDemand",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 1,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now,
                    EndDateTime = DateTime.Now.AddMinutes(30),
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                },
                new Appointments {
                    Id = 3,
                    AppointmentType = "Scheduled",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 3,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now,
                    EndDateTime = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                }
            };
            List<Providers> providers = new()
            {
                new Providers
                {
                    ProviderId = 1,
                    FirstName = "Rob1",
                    LastName = "Provider"
                },
                new Providers
                {
                    ProviderId= 2,
                     FirstName = "Rob2",
                     LastName = "Provider"
                }
            };
            List<Patients> patients = new()
            {
                new Patients
                {
                    PatientId = 1,
                    FirstName = "Bob1",
                    LastName = "Patient"
                },
                new Patients
                {
                     PatientId = 2,
                     FirstName = "Bob2",
                     LastName = "Patient"
                }
            };
            List<VendorConsultRoomAttributes> VendorConsultRoomAttributes = new()
            {
                new VendorConsultRoomAttributes
                {
                    Id = 1,
                    ConsultationID = 1,
                    VendorChatId = Guid.NewGuid().ToString(),
                    VendorConsultRoomId = Guid.NewGuid().ToString(),
                }
            };

            // Data Layer
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDBContext(appontmentlist, VendorConsultRoomAttributes, providers, patients);
            IVideoService videoService = Mock.Of<IVideoService>();

            SaveVendorConsultRoom saveVendorConsultRoom = new(mockConsultationCommandDbContext.Object, videoService);
            var resultOfConsultRoomToken = await saveVendorConsultRoom.ExecuteAsync(addParticipatData);

            // Service Layer
            var mockHandler = new Mock<IExecuteDataRequestAsync<AddParticipatData, Response<VendorConsultRoomTokens>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<AddParticipatData>())).ReturnsAsync(resultOfConsultRoomToken);

            var handler = new SaveVendorConsultRoomCommandHandlers(mockHandler.Object);
            var handlerOutput =  await handler.Handle(new SaveVendorConsultRoomCommand(addParticipatData), cancellationToken: CancellationToken.None);

            // API Layer
            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            mockMediator.Setup(m => m.Send(It.IsAny<SaveVendorConsultRoomCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(handlerOutput);

            var controller = new VendorConsultRoomController(mockCommandService.Object, mockMediator.Object);

            //Act
            var result = await controller.SaveVendorConsultRoom(addParticipatData.appointmentId, addParticipatData.entityType, addParticipatData.providerconsultId);

            //Assert
            Assert.NotNull(result.Value);
        }

        private static Mock<ConsultationCommandDbContext> MockConsultationCommandDBContext(List<Appointments> appointments, List<VendorConsultRoomAttributes> vendorConsultRoomAttributes, List<Providers> providers, List<Patients> patients)
        {
            var mockDbSetOfAppointment = AsDbSetMock(appointments);
            var mockDbSetOfConsultRoom = AsDbSetMock(vendorConsultRoomAttributes);
            var mockDbSetOfProvider = AsDbSetMock(providers);
            var mockDbSetOfPatient = AsDbSetMock(patients);

            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = new(options);

            mockConsultationCommandDbContext.Setup(x => x.Appointments)
                .Returns(mockDbSetOfAppointment.Object);

            mockConsultationCommandDbContext.Setup(x => x.Providers)
                .Returns(mockDbSetOfProvider.Object);

            mockConsultationCommandDbContext.Setup(x => x.Patients)
                .Returns(mockDbSetOfPatient.Object);

            mockConsultationCommandDbContext.Setup(x => x.VendorConsultRoomAttributes)
                .Returns(mockDbSetOfConsultRoom.Object);

            mockConsultationCommandDbContext.Setup(x => x.VendorConsultRoomTokens.AddAsync(It.IsAny<VendorConsultRoomTokens>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<VendorConsultRoomTokens>>());

            mockConsultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return mockConsultationCommandDbContext;
        }
        private static Mock<DbSet<T>> AsDbSetMock<T>(IEnumerable<T> list) where T : class
        {
            IQueryable<T> queryableList = list.AsQueryable();
            Mock<DbSet<T>> dbSetMock = new();
            dbSetMock.As<IQueryable<T>>().Setup(x => x.Provider).Returns(queryableList.Provider);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.Expression).Returns(queryableList.Expression);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.ElementType).Returns(queryableList.ElementType);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.GetEnumerator()).Returns(() => queryableList.GetEnumerator());
            return dbSetMock;
        }
    }
}
