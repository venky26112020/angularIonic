﻿using Consultations.API.Controllers;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Service.CommandHandlers;
using Consultations.Service.QueryHandlers;
using dCaf.Core;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultations.Tests.Controllers
{
    public class PatientReasonVisitControllerTests
    {

        private readonly Mock<IExecuteDataRequestAsync<int, PatientsReasonVisits>> _mockExecutePatientReason;
        public PatientReasonVisitControllerTests()
        {
            _mockExecutePatientReason = new();
        }
        [Fact]
        public async Task PatientQueue_Should_ReturnSuccess_WhenCallController()
        {
            //Arrange            
            var mockMediator = new Mock<IMediator>();
            var mockCommandService = new Mock<ICommandQueryService>();
            var getPatientReasonhandler = new GetPatientReasonsByIdQueryHandler(_mockExecutePatientReason.Object);
            await getPatientReasonhandler.Handle(new GetPatientReasonsQuery(new()), cancellationToken: CancellationToken.None);

            //Act
            PatientReasonVisitController onsultationsController = new PatientReasonVisitController(mockCommandService.Object, mockMediator.Object);
            var result = await onsultationsController.GetPatientReasonForVisits(1);

            //Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task PatientQueue_Should_ReturnFailure_WhenCallController()
        {
            //Arrange            
            var mockMediator = new Mock<IMediator>();
            var mockCommandService = new Mock<ICommandQueryService>();
            var getPatientReasonhandler = new GetPatientReasonsByIdQueryHandler(_mockExecutePatientReason.Object);
            await getPatientReasonhandler.Handle(new GetPatientReasonsQuery(new()), cancellationToken: CancellationToken.None);

            //Act
            PatientReasonVisitController onsultationsController = new PatientReasonVisitController(mockCommandService.Object, mockMediator.Object);
            var result = await onsultationsController.GetPatientReasonForVisits(0);

            //Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task SavePatientReasonforvisit_Should_Return_Success()
        {
            // Arrange                       
            var patientsReasonVisits = new PatientsReasonVisits()
            {
                Id = 0,
                AppointmentId = 1,
                PatientId = 1,
                ReasonForVisit = "System"
            };
            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var controller = new PatientReasonVisitController(mockCommandService.Object, mockMediator.Object);

            var mockHandler = new Mock<IExecuteDataRequestAsync<PatientsReasonVisits, ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<PatientsReasonVisits>())).ReturnsAsync(It.IsAny<ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>);
            var handler = new SavePatientReasonVisistCommandHandler(mockHandler.Object);
            await handler.Handle(new SavePatientReasonVisistCommand(patientsReasonVisits), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.SavePatientReasonForVisist(patientsReasonVisits);

            //Assert
            Assert.Null(result);
        }
        [Fact]
        public async Task SavePatientReasonforvisit_Should_Return_Failure()
        {
            // Arrange                       
            var patientsReasonVisitsFailure = new PatientsReasonVisits();
            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var controller = new PatientReasonVisitController(mockCommandService.Object, mockMediator.Object);
            var mockHandler = new Mock<IExecuteDataRequestAsync<PatientsReasonVisits, ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<PatientsReasonVisits>())).ReturnsAsync(It.IsAny<ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>);
            var handler = new SavePatientReasonVisistCommandHandler(mockHandler.Object);
            await handler.Handle(new SavePatientReasonVisistCommand(patientsReasonVisitsFailure), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.SavePatientReasonForVisist(patientsReasonVisitsFailure);

            //Assert
            Assert.NotNull(result);
        }
    }
}
