﻿using Consultations.API.Controllers;
using Consultations.API.Models;
using Consultations.Core.Domain;
using Consultations.Data.Queries;
using Consultations.Service.CommandHandlers;
using Consultations.Service.QueryHandlers;
using dCaf.Core;
using MediatR;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Azure.Core.HttpHeader;

namespace Consultations.Tests.Controllers
{
    public class SoapNotesControllerTests
    {
        [Fact]
        public async Task GetSOAPNoteByConsultationId()
        {
            // Arrange
            var consultationId = 1;
            List<ConsultSoapNotes> notes = new()
            {
                new ConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Subjective",
                    Description = "Test Subjective",
                    ConsultationId = 1
                },
                new ConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Objective",
                    Description = "Test Objective",
                    ConsultationId = 1
                }
            };
            var response = new Response<List<ConsultSoapNotes>>
            {
                Result = notes,
                Errors = new Dictionary<string, string[]>()
            };
            var mockMediator = new Mock<IMediator>();

            var mockHandler = new Mock<IExecuteDataRequestAsync<int, Response<List<ConsultSoapNotes>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<int>())).ReturnsAsync(response);

            var handler = new GetSoapNotesQueryHandler(mockHandler.Object);
            var handlerOutput = await handler.Handle(new GetSoapNotesQuery(consultationId), cancellationToken: CancellationToken.None);

            mockMediator.Setup(m => m.Send(It.IsAny<GetSoapNotesQuery>(), It.IsAny<CancellationToken>())).ReturnsAsync(handlerOutput);

            //Act
            var controller = new SoapNotesController(mockMediator.Object);
            var result = await controller.GetSoapNotesById(consultationId);

            //Assert
            Assert.NotNull(result.Result);
        }

        [Fact]
        public async Task SaveSOAPNotesInfo()
        {
            // Arrange
            List<ConsultSoapNotes> notes = new()
            {
                new ConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Subjective",
                    Description = "Test Subjective",
                    ConsultationId = 1
                },
                new ConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Objective",
                    Description = "Test Objective",
                    ConsultationId = 1
                }
            };
            var response = new Response<string>
            {
                Result = "Created successfully",
                Errors = new Dictionary<string, string[]>()
            };
            var mockMediator = new Mock<IMediator>();

            var mockHandler = new Mock<IExecuteDataRequestAsync<List<ConsultSoapNotes>, Response<string>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<List<ConsultSoapNotes>>())).ReturnsAsync(response);

            var handler = new SaveSoapNotesCommandHandler(mockHandler.Object);
            var handlerOutput = await handler.Handle(new SaveSoapNotesCommand(notes), cancellationToken: CancellationToken.None);

            mockMediator.Setup(m => m.Send(It.IsAny<SaveSoapNotesCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(handlerOutput);

            //Act
            var controller = new SoapNotesController(mockMediator.Object);
            var result = await controller.SaveSoapNotesInfo(notes);

            //Assert
            Assert.NotNull(result.Result);
        }

        [Fact]
        public async Task UpdateSOAPNotesInfo()
        {
            // Arrange
            List<UpdateConsultSoapNotes> notes = new()
            {
                new UpdateConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Subjective",
                    Description = "Test Subjective",
                    ConsultationId = 1
                },
                new UpdateConsultSoapNotes
                {
                    UpdatedBy = "system",
                    CreatedBy = "system",
                    UpdatedOn = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    EntityType = "Objective",
                    Description = "Test Objective",
                    ConsultationId = 1
                }
            };
            var response = new Response<string>
            {
                Result = "Updated successfully",
                Errors = new Dictionary<string, string[]>()
            };
            var mockMediator = new Mock<IMediator>();

            var mockHandler = new Mock<IExecuteDataRequestAsync<List<UpdateConsultSoapNotes>, Response<string>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<List<UpdateConsultSoapNotes>>())).ReturnsAsync(response);

            var handler = new UpdateSoapNotesInfoCommandHandler(mockHandler.Object);
            var handlerOutput = await handler.Handle(new UpdateSoapNotesInfoCommand(notes), cancellationToken: CancellationToken.None);

            mockMediator.Setup(m => m.Send(It.IsAny<UpdateSoapNotesInfoCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(handlerOutput);

            //Act
            var controller = new SoapNotesController(mockMediator.Object);
            var result = await controller.UpdateSoapNotesInfo(notes);

            //Assert
            Assert.NotNull(result.Result);
        }

        
    }
}
