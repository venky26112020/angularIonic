﻿using Consultations.API.Controllers;
using Consultations.Core;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Service.CommandHandlers;
using Consultations.Service.QueryHandlers;
using dCaf.Core;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using static Azure.Core.HttpHeader;


namespace Consultations.Tests.Controllers
{
    public class AppointmentControllerTests
    {
        [Fact]
        public async Task SavePatientAppointment_Should_Call_Controller()
        {
            //Arrange
            SaveAppointment appointments = new SaveAppointment()
            {
                AppointmentType = "Scheduled",
                ConsultType = "Chat",
                CreatedBy = "Mahesh",
                InstanceId = 1,
                PatientId = 1,
                ProgramId = 1,
                ProviderId = 1,
                StartDateTime = DateTime.Now,
                EndDateTime = DateTime.Now.AddMinutes(30),
                CreatedOn = DateTime.Now,
                Status = "A",
                Requestor = "Mahesh",
                RequestorLocation = "Hyderabad",
                ConsultTimezone = "UTC"
            };

            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var controller = new AppointmentsController(mockCommandService.Object, mockMediator.Object,null);

            var mockHandler = new Mock<IExecuteDataRequestAsync<SaveAppointment, ActionResult<dCaf.Core.Response<SaveAppointment>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<SaveAppointment>())).ReturnsAsync(It.IsAny<ActionResult<dCaf.Core.Response<SaveAppointment>>>);
            var handler = new SavePatientAppointmentCommandHandler(mockHandler.Object);
            await handler.Handle(new SavePatientAppointmentInfoCommand(appointments), cancellationToken: CancellationToken.None);

            //Act
            var result = await controller.SavePatientAppointment(appointments);

            //Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task UpdatePatientLock_Should_Success()
        {
            //Arrange
            UpdateLockInfo updateLockInfo = new UpdateLockInfo()
            {
                Id = 1,
                IsLocked = true,
                LockedBy = "Ranjeet"
            };

            var response = new Response<UpdateLockInfo>
            {
                Result = updateLockInfo,
                Errors = new Dictionary<string, string[]>()
            };

            var mockCommandService = new Mock<ICommandQueryService>();
            var mockMediator = new Mock<IMediator>();

            var mockHandler = new Mock<IExecuteDataRequestAsync<UpdateLockInfo, ActionResult<dCaf.Core.Response<UpdateLockInfo>>>>();
            mockHandler.Setup(x => x.ExecuteAsync(It.IsAny<UpdateLockInfo>())).ReturnsAsync(response);

            var handler = new UpdatePatientLockInfoCommandHandler(mockHandler.Object);
            var handlerOutput = await handler.Handle(new UpdatePatientLockInfoCommand(updateLockInfo), cancellationToken: CancellationToken.None);

            mockMediator.Setup(m => m.Send(It.IsAny<UpdatePatientLockInfoCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(handlerOutput);

            //Act
            var controller = new AppointmentsController(mockCommandService.Object, mockMediator.Object, null);
            var result = await controller.UpdatePatientLock(updateLockInfo);

            //Assert
            Assert.NotNull(result.Value.Result);
        }

    }
}
