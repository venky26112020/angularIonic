﻿using Consultations.API.Controllers;
using Consultations.Core.Domain;
using Consultations.Service.QueryHandlers;
using dCaf.Core;
using MediatR;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultations.Tests.Controllers
{
    public class ProductMedicalCodesControllerTests
    {
        private readonly Mock<IExecuteDataRequestAsync<string, List<ProductMedicalCodes>>> _mockExecuteQueuePatient;
        public ProductMedicalCodesControllerTests()
        {
            _mockExecuteQueuePatient = new();
        }
        [Fact]
        public async Task GetProductMedicalCodes_Should_ReturnSuccess_WhenCallController()
        {
            string producttype = "PA";
            //Arrange            
            var mockMediator = new Mock<IMediator>();
            var getProductmedicalQueryHandlers = new GetProductmedicalQueryHandlers(_mockExecuteQueuePatient.Object);
            await getProductmedicalQueryHandlers.Handle(new GetProductmedicalQuery(producttype), cancellationToken: CancellationToken.None);



            //Act
            ProductMedicalCodesController onsultationsController = new ProductMedicalCodesController(mockMediator.Object);
            var result = await onsultationsController.GetProductMedicalCodes(producttype);



            //Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task GetProductMedicalCodes_Should_ReturnFailure_WhenCallController()
        {

            //Arrange
            string producttype = "";
            var mockMediator = new Mock<IMediator>();
            var getProductmedicalQueryHandlers = new GetProductmedicalQueryHandlers(_mockExecuteQueuePatient.Object);
            await getProductmedicalQueryHandlers.Handle(new GetProductmedicalQuery(producttype), cancellationToken: CancellationToken.None);



            //Act
            ProductMedicalCodesController onsultationsController = new ProductMedicalCodesController(mockMediator.Object);
            var result = await onsultationsController.GetProductMedicalCodes(producttype);

            //Assert
            Assert.NotNull(result);
        }
    }
}
