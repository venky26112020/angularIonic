﻿using Consultations.Core.Domain;
using Consultations.Data.Commands;
using Consultations.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Consultations.API.Models;
using Azure;

namespace Consultations.Tests.Commands
{
    public class PatientIntakeResponsesCommandHandlerTests
    {
        [Fact]
        public async Task SavePatientintakeresponse_Should_Return_Success()
        {
            // Arrange
            List<PatientIntakeResponses> intakelist = new()
            {
               new PatientIntakeResponses
               {
                  AppointmentId =1,
                  PatientId=1,
                  Question="",
                  QuestionResponse="",
                  FollowupQuestion="",
                  FollowupResponse="",
                  IsWeightageTitle=true
                }
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext(intakelist);

            //Act
            SavePatientsIntakeResponsesInfo savepatientintake = new SavePatientsIntakeResponsesInfo(mockConsultationCommandDbContext.Object);
            var result = await savepatientintake.ExecuteAsync(intakelist);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<string>>>(result);
        }

        [Fact]
        public async Task SavePatientintakerespose_Should_Return_Error()
        {
            // Arrange            
            List<PatientIntakeResponses> intakelist = new()
            {
               
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext(intakelist);

            //Act
            SavePatientsIntakeResponsesInfo savepatientintake = new SavePatientsIntakeResponsesInfo(mockConsultationCommandDbContext.Object);
            var result = await savepatientintake.ExecuteAsync(intakelist);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<string>>>(result);
        }

        public static Mock<ConsultationCommandDbContext> MockConsultationCommandDbContext(List<PatientIntakeResponses> intakelist)
        {
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var consultationCommandDbContext = new Mock<ConsultationCommandDbContext>(options);
           consultationCommandDbContext.Setup(x => x.PatientsIntakeResponses.AddRangeAsync(intakelist,CancellationToken.None));
            consultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return consultationCommandDbContext;
        }
    }
}
