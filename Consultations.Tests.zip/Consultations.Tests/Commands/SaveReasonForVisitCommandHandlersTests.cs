﻿using Consultations.Core.Domain;
using Consultations.Data.Commands;
using Consultations.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consultations.Tests.Commands
{
    public class SaveReasonForVisitCommandHandlersTests
    {
        [Fact]
        public async Task SavePatientreasonforvist_Should_Return_Success()
        {
            // Arrange
            var patientsReasonVisits = new PatientsReasonVisits
            {
                Id = 0,
                AppointmentId = 1,
                PatientId = 1,
                ReasonForVisit = "System",
                CreatedBy = "User",
                UpdatedBy = "User"
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext(patientsReasonVisits);

            //Act
            SavePatientReasonForVisist savepatientreason = new SavePatientReasonForVisist(mockConsultationCommandDbContext.Object);
            var result = await savepatientreason.ExecuteAsync(patientsReasonVisits);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>(result);
        }

        [Fact]
        public async Task SavePatientreasonforvist_Should_Return_Error()
        {
            // Arrange            
            var patientsReasonVisits = new PatientsReasonVisits();
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext(patientsReasonVisits);

            //Act
            SavePatientReasonForVisist savepatientreason = new SavePatientReasonForVisist(mockConsultationCommandDbContext.Object);
            var result = await savepatientreason.ExecuteAsync(patientsReasonVisits);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<PatientsReasonVisits>>>(result);
        }

        public static Mock<ConsultationCommandDbContext> MockConsultationCommandDbContext(PatientsReasonVisits patientsReasonVisits)
        {
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var consultationCommandDbContext = new Mock<ConsultationCommandDbContext>(options);
            consultationCommandDbContext.Setup(x => x.PatientsReasonForVisits.Add(patientsReasonVisits)).Returns(It.IsAny<EntityEntry<PatientsReasonVisits>>());
            consultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return consultationCommandDbContext;
        }
    }
}
