﻿using Consultations.API.Models;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Data.Commands;
using Consultations.Data.TwilioService;
using dCaf.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Moq;


namespace Consultations.Tests.Commands
{
    public class SaveVendorConsultRoomCommandHandlersTests
    {
        [Theory]
        [InlineData(4, "provider", "1")]
        [InlineData(3, "provider", "3")]
        [InlineData(1, "provider", "1")]
        [InlineData(1, "patient", "1")]
        [InlineData(3, "patient", "3")]
        [InlineData(1, "admin", "1")]
        [InlineData(2, "provider", "1")]
        public async Task SaveConsultRoom(int consultationId, string entityType, string providerconsultId)
        {
            // Arrange
            List<Appointments> appontmentlist = new ()
            {
                new Appointments {
                    Id = 1,
                    AppointmentType = "Scheduled",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 1,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now.AddMinutes(-10),
                    EndDateTime = DateTime.Now.AddMinutes(10),
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                },
                new Appointments {
                    Id = 2,
                    AppointmentType = "OnDemand",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 1,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now,
                    EndDateTime = DateTime.Now.AddMinutes(30),
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                },
                new Appointments {
                    Id = 3,
                    AppointmentType = "Scheduled",
                    ConsultType = "Chat",
                    CreatedBy = "Venky",
                    InstanceId = 1,
                    PatientId = 3,
                    ProgramId = 1,
                    ProviderId = 1,
                    StartDateTime = DateTime.Now,
                    EndDateTime = DateTime.Now,
                    CreatedOn = DateTime.Now,
                    Status = "A",
                    Requestor = "Venky",
                    RequestorLocation = "Hyderabad",
                    ConsultTimezone = "UTC",
                    PatientFirstName = "Venkata",
                    PatientLastName = "Krishna"
                }
            };
            List<Providers> providers = new()
            {
                new Providers
                {
                    ProviderId = 1,
                    FirstName = "Rob1",
                    LastName = "Provider"
                },
                new Providers
                {
                    ProviderId= 2,
                     FirstName = "Rob2",
                     LastName = "Provider"
                }
            };
            List<Patients> patients = new()
            {
                new Patients
                {
                    PatientId = 1,
                    FirstName = "Bob1",
                    LastName = "Patient"
                },
                new Patients
                {
                     PatientId = 2,
                     FirstName = "Bob2",
                     LastName = "Patient"
                }
            };
            List<VendorConsultRoomAttributes> VendorConsultRoomAttributes = new ()
            {
                new VendorConsultRoomAttributes
                {
                    Id = 1,
                    ConsultationID = 1,
                    VendorChatId = Guid.NewGuid().ToString(),
                    VendorConsultRoomId = Guid.NewGuid().ToString(),
                }
            };
            AddParticipatData addParticipatData = new AddParticipatData()
            {
                appointmentId = consultationId,
                entityType = entityType,
                providerconsultId = providerconsultId
            };



            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDBContext(appontmentlist, VendorConsultRoomAttributes,providers,patients);
            IVideoService videoService = Mock.Of<IVideoService>();
            

            // Act
            SaveVendorConsultRoom saveVendorConsultRoom = new(mockConsultationCommandDbContext.Object, videoService);

            var resultOfConsultRoomToken = await saveVendorConsultRoom.ExecuteAsync(addParticipatData);

            // Assert
            Assert.NotNull(resultOfConsultRoomToken);
            Assert.IsType<Response<VendorConsultRoomTokens>>(resultOfConsultRoomToken);
        }

        private static Mock<ConsultationCommandDbContext> MockConsultationCommandDBContext(List<Appointments> appointments,List<VendorConsultRoomAttributes> vendorConsultRoomAttributes, List<Providers> providers, List<Patients> patients)
        {
            var mockDbSetOfAppointment = AsDbSetMock(appointments);
            var mockDbSetOfConsultRoom = AsDbSetMock(vendorConsultRoomAttributes);
            var mockDbSetOfProvider = AsDbSetMock(providers);
            var mockDbSetOfPatient = AsDbSetMock(patients);

            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = new(options);

            mockConsultationCommandDbContext.Setup(x => x.VendorConsultRoomAttributes.AddAsync(It.IsAny<VendorConsultRoomAttributes>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<VendorConsultRoomAttributes>>());

            mockConsultationCommandDbContext.Setup(x => x.Appointments)
                .Returns(mockDbSetOfAppointment.Object);

            mockConsultationCommandDbContext.Setup(x => x.Providers)
                .Returns(mockDbSetOfProvider.Object);

            mockConsultationCommandDbContext.Setup(x => x.Patients)
                .Returns(mockDbSetOfPatient.Object);

            mockConsultationCommandDbContext.Setup(x => x.VendorConsultRoomAttributes)
                .Returns(mockDbSetOfConsultRoom.Object);

            mockConsultationCommandDbContext.Setup(x => x.VendorConsultRoomTokens.AddAsync(It.IsAny<VendorConsultRoomTokens>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<VendorConsultRoomTokens>>());

            mockConsultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return mockConsultationCommandDbContext;
        }
        private static Mock<DbSet<T>> AsDbSetMock<T>(IEnumerable<T> list) where T : class
        {
            IQueryable<T> queryableList = list.AsQueryable();
            Mock<DbSet<T>> dbSetMock = new();
            dbSetMock.As<IQueryable<T>>().Setup(x => x.Provider).Returns(queryableList.Provider);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.Expression).Returns(queryableList.Expression);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.ElementType).Returns(queryableList.ElementType);
            dbSetMock.As<IQueryable<T>>().Setup(x => x.GetEnumerator()).Returns(() => queryableList.GetEnumerator());
            return dbSetMock;
        }
    }
}
