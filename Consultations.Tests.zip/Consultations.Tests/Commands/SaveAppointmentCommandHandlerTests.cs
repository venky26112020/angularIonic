﻿using Consultations.Core;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Data.Commands;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Moq;
using System;

namespace Consultations.Tests.Commands
{
    public class SaveAppointmentCommandHandlerTests
    {

        [Fact]
        public async Task SaveAppointment_Should_Return_Success()
        {
            // Arrange                       
            var appointments = new SaveAppointment()
            {
                AppointmentType = "Scheduled",
                ConsultType = "Chat",
                CreatedBy = "Mahesh",
                InstanceId = 1,
                PatientId = 1,
                ProgramId = 1,
                ProviderId = 1,
                StartDateTime = DateTime.Now,
                EndDateTime = DateTime.Now.AddMinutes(30),
                CreatedOn = DateTime.Now,
                Status = "A",
                Requestor = "Mahesh",
                RequestorLocation = "Hyderabad",
                ConsultTimezone = "UTC"
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext();

            //Act
            SavePatientAppointement savePatientAppointement = new SavePatientAppointement(mockConsultationCommandDbContext.Object);
            var result = await savePatientAppointement.ExecuteAsync(appointments);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<SaveAppointment>>>(result);
        }

        [Fact]
        public async Task SaveAppointment_Should_SaveAppointmentHistory_Return_Success()
        {
            // Arrange                       
            var appointments = new SaveAppointment()
            {
                Id = 1,
                AppointmentType = "Scheduled",
                ConsultType = "Chat",
                CreatedBy = "Mahesh",
                InstanceId = 1,
                PatientId = 1,
                ProgramId = 1,
                ProviderId = 1,
                StartDateTime = DateTime.Now,
                EndDateTime = DateTime.Now.AddMinutes(30),
                CreatedOn = DateTime.Now,
                Status = "A",
                Requestor = "Mahesh",
                RequestorLocation = "Hyderabad",
                ConsultTimezone = "UTC"
            };

            var appointmentHistory = new AppointmentHistory()
            {
                Status = "A",
                Description = "Active",
                ReleaseTimeBlock = ""
            };

            var patientsReasonVisits = new PatientsReasonVisits()
            {
                AppointmentId=1,
                PatientId=1,
                ReasonForVisit ="Cold"                
            };

            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext();

            //Act
            SavePatientAppointement savePatientAppointement = new SavePatientAppointement(mockConsultationCommandDbContext.Object);
            var result = await savePatientAppointement.ExecuteAsync(appointments);

            //Assert
            Assert.NotNull(result);           
            Assert.IsType<ActionResult<dCaf.Core.Response<SaveAppointment>>>(result);
        }

        [Fact]
        public async Task SaveAppointment_Should_Return_Error()
        {
            // Arrange                       
            var appointments = new SaveAppointment()
            {
                Id = 1,
                AppointmentType = "Scheduled",
                ConsultType = "Chat",
                CreatedBy = "Mahesh",
                InstanceId = 1,
                PatientId = 1,
                ProgramId = 1,
                ProviderId = 1,
                StartDateTime = DateTime.Now.AddMinutes(30),
                EndDateTime = DateTime.Now,
                CreatedOn = DateTime.Now,
                Status = "A",
                Requestor = "Mahesh",
                RequestorLocation = "Hyderabad",
                ConsultTimezone = "UTC"
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext();

            //Act
            SavePatientAppointement savePatientAppointement = new SavePatientAppointement(mockConsultationCommandDbContext.Object);
            var result = await savePatientAppointement.ExecuteAsync(appointments);

            //Assert
            Assert.NotNull(result);
            //Assert.Equal("Start datetime must be less than end datetime", result.Value.Errors["DateRange"][0]);
        }

        private Mock<ConsultationCommandDbContext> MockConsultationCommandDbContext()
        {
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var mockConsultationCommandDbContext = new Mock<ConsultationCommandDbContext>(options);
            mockConsultationCommandDbContext.Setup(x => x.Appointments.AddAsync(It.IsAny<Appointments>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<Appointments>>());
            mockConsultationCommandDbContext.Setup(x => x.PatientsReasonForVisits.AddAsync(It.IsAny<PatientsReasonVisits>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<PatientsReasonVisits>>());
            mockConsultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return mockConsultationCommandDbContext;
        }
    }
}
