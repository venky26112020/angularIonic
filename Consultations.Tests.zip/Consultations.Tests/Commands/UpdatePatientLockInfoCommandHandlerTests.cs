﻿using Consultations.Core;
using Consultations.Core.Domain;
using Consultations.Data;
using Consultations.Data.Commands;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Moq;
using System;

namespace Consultations.Tests.Commands
{
    public class UpdatePatientLockInfoCommandHandlerTests
    {

        [Fact]
        public async Task UpdatePatientLockInfo_Should_Return_Success()
        {
            // Arrange                       
            var updateLockInfo = new UpdateLockInfo()
            {
                Id = 1,
                IsLocked = true,
                LockedBy = "Ranjeet"
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext();

            //Act
            UpdatePatientLockInfo updatePatientLockInfo = new UpdatePatientLockInfo(mockConsultationCommandDbContext.Object);
            var result = await updatePatientLockInfo.ExecuteAsync(updateLockInfo);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<ActionResult<dCaf.Core.Response<UpdateLockInfo>>>(result);
        }

        [Fact]
        public async Task UpdatePatientLockInfo_Should_Return_Error()
        {
            // Arrange                       
            var updateLockInfo = new UpdateLockInfo()
            {
                Id = 999999999,
                IsLocked = true,
                LockedBy = "Ranjeet"
            };
            Mock<ConsultationCommandDbContext> mockConsultationCommandDbContext = MockConsultationCommandDbContext();

            //Act
            UpdatePatientLockInfo updatePatientLockInfo = new UpdatePatientLockInfo(mockConsultationCommandDbContext.Object);
            var result = await updatePatientLockInfo.ExecuteAsync(updateLockInfo);

            //Assert
            Assert.NotNull(result);            
        }

        private Mock<ConsultationCommandDbContext> MockConsultationCommandDbContext()
        {
            var options = new DbContextOptionsBuilder<ConsultationCommandDbContext>().UseSqlServer().Options;
            var mockConsultationCommandDbContext = new Mock<ConsultationCommandDbContext>(options);
            mockConsultationCommandDbContext.Setup(x => x.Appointments.AddAsync(It.IsAny<Appointments>(), CancellationToken.None))
                .ReturnsAsync(It.IsAny<EntityEntry<Appointments>>());            
            mockConsultationCommandDbContext.Setup(x => x.SaveChangesAsync(CancellationToken.None));

            return mockConsultationCommandDbContext;
        }
    }
}
