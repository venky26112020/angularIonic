﻿using dCaf.Core;
using Members.Core.Domain;
using Members.Data;
using Members.Data.Queries;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Members.Tests.Queries
{
    public class GetHealthProfileHandlersTests
    {
        [Fact]
        public async Task Execute_Should_ReturnSuccess_WhenCallGetHealthProfile()
        {

            //Arrange            
            var data = new List<HealthProfiles>
            {
                new HealthProfiles { PatientId =1, NetworkId =1, Status ="A" },
                new HealthProfiles {  PatientId = 2, NetworkId =2, Status ="A" }
            }.AsAsyncQueryable();
            var mockSet = new Mock<DbSet<HealthProfiles>>();
            Mock<MemberQueryDbContext> mockcmemberQueryContext = MockAsyncQueryable(data, mockSet);

            //Act
            GetHealthProfile getHealthProfile = new GetHealthProfile(mockcmemberQueryContext.Object);            
            var result = await getHealthProfile.ExecuteAsync(1);

            //Assert
            Assert.NotNull(result);
            Assert.IsType<Response<List<HealthProfiles>>>(result);
        }


        private static Mock<MemberQueryDbContext> MockAsyncQueryable(IQueryable<HealthProfiles> data, Mock<DbSet<HealthProfiles>> mockSet)
        {
            mockSet.As<IAsyncEnumerable<HealthProfiles>>().Setup(m => m.GetAsyncEnumerator(CancellationToken.None))
                            .Returns(new AsyncEnumeratorWrapper<HealthProfiles>(data.GetEnumerator()));
            mockSet.As<IQueryable<HealthProfiles>>().Setup(m => m.Provider).Returns(new AsyncQueryProvider<HealthProfiles>(data.Provider));
            var options = new DbContextOptionsBuilder<MemberQueryDbContext>().UseSqlServer().Options;
            mockSet.As<IQueryable<HealthProfiles>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<HealthProfiles>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<HealthProfiles>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<HealthProfiles>>().Setup(m => m.GetEnumerator()).Returns(() => data.GetEnumerator());

            var mockconfigurationQueryContext = new Mock<MemberQueryDbContext>(options);
            //var queryBase = new QueryBase(mockconfigurationQueryContext.Object);

            mockconfigurationQueryContext.Setup(x => x.HealthProfiles).Returns(mockSet.Object);
            return mockconfigurationQueryContext;
        }
    }
}
